document/addEventListener('DOMContentLoaded', function () {
    fetch('/post')
    .then (( Response) => Response.json())
    .then ((posts) => {
        const postContainer = document.getElementById('posts');
        postContainer.innerHTML = posts
        .map(
            (post) => `
            <div class="post ${post.category}">
            $ {
            post.iamge
            ? '<img calss="post-img" src="{post.image}" alt="${post.title}"'
            }
            <h3 calss="post-category"> ${post.category}</h3>
            </div>
            `
        )
        .join("");
    });
    .catch((error) => {
        console.error("Error fetching posts:", error);
        const postContainer = document.getElementById('posts')
        postContainer.innerHTML="<p>Error Fetching posts.</p>"
    });
});
let header = document.querySelector("header")

window.addEventListener("scroll", () => {
    header.classList.toggle("shadow", window.scrollY > 0);
});